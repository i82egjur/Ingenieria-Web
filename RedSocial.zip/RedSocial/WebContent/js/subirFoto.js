function mostrar(){
  var archivo = document.getElementById("multimedia").files[0];
  var reader = new FileReader();
  if (archivo) {
    reader.readAsDataURL(archivo );
    reader.onloadend = function () {
      document.getElementById("previsualizacionDocumentoSubido").src = reader.result;
      document.getElementById("binarioApasar").value = reader.result;

    }
  }
}