package es.uco.iw.mvc.modelo.data.clienteTiburonToro.gestCTT.impl;


import java.util.Vector;
import javax.servlet.ServletContext;

import es.uco.iw.mvc.modelo.business.AdministradorTiburonBlanco;
import es.uco.iw.mvc.modelo.business.ClienteTiburonToro;
import es.uco.iw.mvc.modelo.business.EstadoRemora;
import es.uco.iw.mvc.modelo.business.RemoraRegistradaDTO;
import es.uco.iw.mvc.modelo.business.TipoRemora;
import es.uco.iw.mvc.modelo.data.clienteTiburonToro.gestCTT.GestCTT;
import es.uco.iw.mvc.modelo.data.clienteTiburonToro.gestCTT.GestSkillCtt;
import es.uco.iw.mvc.modelo.data.remoraRegistrada.GestInformacionRemora.GestRemora;
import es.uco.iw.mvc.modelo.data.remoraRegistrada.controlAcceso.Register;
import es.uco.iw.mvc.modelo.data.remoraRegistrada.impl.GestRemoraImpl;


public class GestCTTImpl  implements GestCTT, Register  
{
	private GestRemora gestorRemora;
	private GestSkillCtt gestorSkills;
	 
	 public GestCTTImpl(ServletContext servletContext)
	 {
	      gestorSkills = new GestSkillCTTImpl(servletContext);
		  gestorRemora = new GestRemoraImpl(servletContext);
		
	 }
	 
	@Override
	public void registrarCTT(ClienteTiburonToro newCliente)
	{
		gestorRemora.register(new RemoraRegistradaDTO(newCliente.getNombreRemora(), newCliente.getApellidos(),
													newCliente.getMail(), newCliente.getPassword(),
													newCliente.getSaltPassword(), newCliente.getTelefono(),
													TipoRemora.ClienteTiburonToro, EstadoRemora.Permitido));
		gestorSkills.addSkill(newCliente.getMail(), newCliente.getSkills());
		
	}
	
	
	public void updateCTT(ClienteTiburonToro updateCliente)
	{
		gestorRemora.updateRemora(new RemoraRegistradaDTO(updateCliente.getNombreRemora(), updateCliente.getApellidos(),
														updateCliente.getMail(), updateCliente.getPassword(),
														updateCliente.getSaltPassword(), updateCliente.getTelefono(),
														TipoRemora.ClienteTiburonToro, updateCliente.getEstado()));
		gestorSkills.addSkill(updateCliente.getMail(), updateCliente.getSkills());
												
	}
	
	public void eraseCTT(String mail)
	{
		gestorRemora.deleteRemora(mail);
	}
	
	
	public ClienteTiburonToro searchCTT(String mail)
	{
		RemoraRegistradaDTO remoraBuscada = gestorRemora.buscarRemora(mail);
		Vector <String> skillsRemoraBuscada = gestorSkills.getSkillsRemora(mail);
		
		ClienteTiburonToro clienteBuscado = new ClienteTiburonToro(remoraBuscada.getNombreRemora(), remoraBuscada.getApellidos(),
																remoraBuscada.getMail(), remoraBuscada.getPasswdEncript(),
																remoraBuscada.getSalt(), remoraBuscada.getTelefono(),
																skillsRemoraBuscada, remoraBuscada.getEstado());
		return clienteBuscado;
	}

	@Override
	public void registrarATB(AdministradorTiburonBlanco newATB) {
		// TODO Auto-generated method stub
		
	}





}
