package es.uco.iw.mvc.modelo.data.clienteTiburonToro.Proyecto;

public interface CompartirProyecto 
{
	public Integer compartir(byte[] multimedia);

}
