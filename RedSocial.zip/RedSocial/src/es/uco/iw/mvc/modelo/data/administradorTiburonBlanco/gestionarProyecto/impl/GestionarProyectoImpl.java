package es.uco.iw.mvc.modelo.data.administradorTiburonBlanco.gestionarProyecto.impl;

public class GestionarProyectoImpl {

}
