package es.uco.iw.mvc.modelo.data.clienteTiburonToro.Proyecto;

import es.uco.iw.mvc.modelo.business.ProyectoDTO;

public interface ActualizarProyecto 
{
	public Integer actualizarProyecto(ProyectoDTO proyectoDTO, int id) ;
	
}
