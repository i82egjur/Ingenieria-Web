package es.uco.iw.mvc.modelo.business;

public class MultimediaDTO 
{
	private Integer ID_proyecto;
	private String  TipoMultimedia;
	private byte[] multimedia;
	
	public MultimediaDTO(Integer ID_proyecto, String tipoMultimedia, byte[] multimedia)
	{
		setID_proyecto(ID_proyecto);
		setTipoMultimedia(tipoMultimedia);
		setMultimedia(multimedia);
	}
	
	public Integer getID_proyecto() {
		return ID_proyecto;
	}
	public void setID_proyecto(Integer iD_proyecto) {
		ID_proyecto = iD_proyecto;
	}
	public String getTipoMultimedia() {
		return TipoMultimedia;
	}
	public void setTipoMultimedia(String tipoMultimedia) {
		TipoMultimedia = tipoMultimedia;
	}
	public byte[] getMultimedia() {
		return multimedia;
	}
	public void setMultimedia(byte[] multimedia) {
		this.multimedia = multimedia;
	}

}
