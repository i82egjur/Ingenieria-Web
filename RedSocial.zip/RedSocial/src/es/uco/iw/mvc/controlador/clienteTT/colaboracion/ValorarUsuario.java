package es.uco.iw.mvc.controlador.clienteTT.colaboracion;

public class ValorarUsuario 
{

}
