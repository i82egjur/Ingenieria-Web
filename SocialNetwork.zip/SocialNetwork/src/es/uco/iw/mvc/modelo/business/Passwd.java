package es.uco.iw.mvc.modelo.business;

public class Passwd 
{
	String passwdEncript;
	String saltEncript;
	
	public Passwd(String passwdEncript, String saltEncript)
	{
		setPasswdEncript(passwdEncript);
		setSaltEncript(saltEncript);
	}

	public String getPasswdEncript() {
		return passwdEncript;
	}

	public void setPasswdEncript(String passwdEncript) {
		this.passwdEncript = passwdEncript;
	}

	public String getSaltEncript() {
		return saltEncript;
	}

	public void setSaltEncript(String saltEncript) {
		this.saltEncript = saltEncript;
	}
	
	

}
