package es.uco.iw.mvc.modelo.business;


public class AdministradorTiburonBlanco 
{
	private String nombreRemora;
	private String apellidos;
	private String mail;
	private Passwd passwd;
	private Integer telefono;
	private EstadoRemora estado;

	
	
	public AdministradorTiburonBlanco (String nombreRemora, String apellidos, String mail, 
							   String password, String saltPassword, Integer telefono, EstadoRemora estado)
	{
		passwd = new Passwd(password, saltPassword);
		setNombreRemora(nombreRemora);
		setApellidos(apellidos);
		setMail(mail);
		setTelefono(telefono);
		setEstado(estado); 
	}


	public String getNombreRemora() {
		return nombreRemora;
	}


	public void setNombreRemora(String nombreRemora) {
		this.nombreRemora = nombreRemora;
	}


	public String getApellidos() {
		return apellidos;
	}


	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}


	public String getMail() {
		return mail;
	}


	public void setMail(String mail) {
		this.mail = mail;
	}


	public String getPasswdEncript()
	{
		return passwd.getPasswdEncript();
	}
	
	public String getSalt()
	{
		return passwd.getSaltEncript();
	}
	
	public void setPasswdEncript(String newPasswdEncript)
	{
		passwd.setPasswdEncript(newPasswdEncript);
	}
	
	public void setSaltEncript(String saltEncript)
	{
		passwd.setSaltEncript(saltEncript);
	}


	public Integer getTelefono() {
		return telefono;
	}


	public void setTelefono(Integer telefono) {
		this.telefono = telefono;
	}


	public EstadoRemora getEstado() {
		return estado;
	}


	public void setEstado(EstadoRemora estado) {
		this.estado = estado;
	}

}
