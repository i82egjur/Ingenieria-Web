package es.uco.iw.mvc.modelo.data.clienteTiburonToro.Proyecto;

import es.uco.iw.mvc.modelo.business.ProyectoDTO;

public interface AnunciarProyecto 
{
	public Integer subirProyecto(ProyectoDTO proyectoDTO);

}
