package es.uco.iw.mvc.modelo.data.clienteTiburonToro.promocion.impl;

import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Properties;
import java.util.Vector;

import javax.servlet.ServletContext;

import es.uco.iw.mvc.modelo.business.PromocionClienteTiburonToroDTO;
import es.uco.iw.mvc.modelo.business.TipoRemora;
import es.uco.iw.mvc.modelo.data.clienteTiburonToro.promocion.GestPromocionRemoraDAO;
import es.uco.iw.mvc.modelo.data.conexionBBDD.DBconnect;
import es.uco.iw.mvc.modelo.data.conexionBBDD.impl.DBconnectImpl;


public class GestPromocionRemoraDAOImpl implements GestPromocionRemoraDAO 
{
	private Connection con;
	private Properties pSQL;
	
	public GestPromocionRemoraDAOImpl(ServletContext servletContext)
	{
		DBconnect dbConnect = new DBconnectImpl(servletContext);
		con = dbConnect.getConnection();
		pSQL = new Properties();
		try
		{
			
			String path = this.getClass().getResource(servletContext.getInitParameter("pathProperties")).toURI().getPath();
			pSQL.load(new FileInputStream(path));
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}
	
	

	public void promocionarClienteTiburonToro(PromocionClienteTiburonToroDTO promocionarUsuario)
	{
		PreparedStatement promocionarUsuarioStatement = null;
	
		try
		{
			promocionarUsuarioStatement=con.prepareStatement(pSQL.getProperty("promocionarRemora"));
			promocionarUsuarioStatement.setString(1, promocionarUsuario.getCorreo());
			promocionarUsuarioStatement.setDate(2, promocionarUsuario.getFechaFinal());
			promocionarUsuarioStatement.setDate(3, promocionarUsuario.getFechaInicio());
			promocionarUsuarioStatement.setString(4, promocionarUsuario.getDescripcionPromocion());

			promocionarUsuarioStatement.executeUpdate();			
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public boolean hasPromocion(String mail)
	{
		ResultSet rs = null;
		PreparedStatement ps = null;
		
		try
		{
			ps = con.prepareStatement(pSQL.getProperty("hasPromocion"));
			ps.setString(1, mail);
		    rs = ps.executeQuery();
			if (rs.next())
			{
				return true;
			}
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return false;
	}
	
	public Vector <PromocionClienteTiburonToroDTO> getClientesTiburonToroPromocionados()
	{
		Vector <PromocionClienteTiburonToroDTO> newVectCTT = new Vector <PromocionClienteTiburonToroDTO>();
		ResultSet rs = null;
		PreparedStatement ps = null;
		
		
		try
		{
			ps = con.prepareStatement(pSQL.getProperty("obtenerRemorasPromocionativas"));
		    rs = ps.executeQuery();
			while (rs.next())
			{
				newVectCTT.add(new PromocionClienteTiburonToroDTO(rs.getString(1), rs.getString(2),
																	rs.getString(3), rs.getString(4),
																	rs.getDate(5), rs.getDate(6)));
			}
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return newVectCTT;
	}
	public PromocionClienteTiburonToroDTO getPromocionCTT(String mail)
	{
		PromocionClienteTiburonToroDTO newCTT = null;
		ResultSet rs = null;
		PreparedStatement ps = null;
		
		
		try
		{
			ps = con.prepareStatement(pSQL.getProperty("obtenerPromocionCTT"));
			ps.setString(1, mail);
		    rs = ps.executeQuery();
			if (rs.next())
			{
				newCTT = new PromocionClienteTiburonToroDTO(rs.getString(1), rs.getString(2),
																	rs.getString(3), rs.getString(4),
																	rs.getDate(5), rs.getDate(6));
			}
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return newCTT;
	}
	
	public void updatePromocionClienteTiburonToro(PromocionClienteTiburonToroDTO promocionarUsuario)
	{
		PreparedStatement updateUsuario = null;
		try
		{
			updateUsuario=con.prepareStatement(pSQL.getProperty("updatePromocionRemora"));
			updateUsuario.setDate(1, promocionarUsuario.getFechaFinal());
			updateUsuario.setDate(2, promocionarUsuario.getFechaInicio());
			updateUsuario.setString(3, promocionarUsuario.getDescripcionPromocion());
			updateUsuario.setString(4, promocionarUsuario.getCorreo());
			

			updateUsuario.executeUpdate();			
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}

}
