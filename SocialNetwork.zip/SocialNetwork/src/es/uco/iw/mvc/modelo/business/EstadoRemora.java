package es.uco.iw.mvc.modelo.business;

public enum EstadoRemora {
	Baneado,
	Permitido

}
