package es.uco.iw.mvc.modelo.data.conexionBBDD.impl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.servlet.ServletContext;

import es.uco.iw.mvc.modelo.data.conexionBBDD.DBconnect;


public class DBconnectImpl implements DBconnect
{
	private Connection conn;
	String direccionServidor;
	String usuario;
	String password;
	String driver;
	
	
	public DBconnectImpl(ServletContext servletContext)
	{
		direccionServidor = servletContext.getInitParameter("direccionServidor");
		usuario = servletContext.getInitParameter("usuario");
		password = servletContext.getInitParameter("password");
		driver = servletContext.getInitParameter("driver");
		conectar();

	}
    
	/*Co	
	/**
	 * Metodo que conecta a nuestra base de datos, con los datos del properties
	 */
	public void conectar()
	{
		try 
    	{
            Class.forName("com.mysql.jdbc.Driver");
            conn = (Connection) DriverManager.getConnection(direccionServidor, usuario, password);  
    	} 
        catch (ClassNotFoundException e) 
        {
            e.printStackTrace();
        } 
        catch (SQLException e)
        {        	
            e.printStackTrace();
        }
		
	}
	/**
	 * Metodo getConnection que devuelve una conexion a la base de datos
	 * @return con -> Devuelve una conexion a la BBDD
	 * @author Jesus Izquierdo Estevez
     * @author Rafael Egea Jurado
	 * @param servletContext 
	 * @return 
	 */
	public Connection getConnection ()
	{
		
		if (conn == null)
		{
			conectar();
		}
		return conn;
		
	}


   	
	
	

}
