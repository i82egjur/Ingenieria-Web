package es.uco.iw.mvc.modelo.business;

public enum TipoRemora {
	AdministradorTiburonBlanco,
	ClienteTiburonToro

}
