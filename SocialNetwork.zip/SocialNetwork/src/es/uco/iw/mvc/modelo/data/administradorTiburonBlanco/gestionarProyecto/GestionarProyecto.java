package es.uco.iw.mvc.modelo.data.administradorTiburonBlanco.gestionarProyecto;

public interface GestionarProyecto {

}
