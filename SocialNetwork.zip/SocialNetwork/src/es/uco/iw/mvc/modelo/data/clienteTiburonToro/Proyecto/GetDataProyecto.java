package es.uco.iw.mvc.modelo.data.clienteTiburonToro.Proyecto;

import java.util.Vector;

import es.uco.iw.mvc.modelo.business.ProyectoDTO;

public interface GetDataProyecto 
{
	public Vector<ProyectoDTO> getMisProyectosColaborativos(String mail);
	public byte[] obtenerMultimedia(Integer id);
	public Vector <String> obtenerSkillsProyecto(Integer id);
	public Vector <String> ObtenerTematicasProyecto(Integer id);
	public Vector <String> ObtenerColaboradoresProyecto (Integer id);
	public ProyectoDTO getProyecto(Integer id);
	public Vector<ProyectoDTO> obtenerTotalProyectos();

}
