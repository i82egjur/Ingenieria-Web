package es.uco.iw.mvc.vista.display;

import java.util.Vector;

import es.uco.iw.mvc.modelo.business.ProyectoDTO;

public class MisProyectosBean {

	Vector <ProyectoDTO> proyectosDTO;
	
	public MisProyectosBean(Vector<ProyectoDTO> proyectosDTO) {
		this.proyectosDTO = proyectosDTO;
	}

	public String getTitulo(int elemento) {
		return proyectosDTO.get(elemento).getTitulo();
	}

	public void setTitulo(String titulo, int elemento) {
		this.proyectosDTO.get(elemento).setTitulo(titulo);
	}

    public String getDescripcion(int elemento) {
		return proyectosDTO.get(elemento).getDescripcion();
	}

	public void setDescripcion(String descripcion, int elemento) {
		this.proyectosDTO.get(elemento).setDescripcion( descripcion);
	}

    public Vector <String> getSkills(int elemento) {
		return proyectosDTO.get(elemento).getSkills();
	}

	public void setSkills(Vector <String> skills, int elemento) {
		this.proyectosDTO.get(elemento).setSkills(skills);
	}

    public Vector <String> getTematicas(int elemento) {
		return proyectosDTO.get(elemento).getTematicas();
	}

	public void setTematicas(Vector <String> tematicas, int elemento) {
		this.proyectosDTO.get(elemento).setTematicas(tematicas);
	}

    public String getPropietario(int elemento) {
		return proyectosDTO.get(elemento).getPropietario();
	}

	public void setPropietario(String propietario, int elemento) {
		this.proyectosDTO.get(elemento).setPropietario(propietario);
	}

	public int getId(int elemento) {
		return proyectosDTO.get(elemento).getId();
	}

	public void setId(int id, int elemento) {
		proyectosDTO.get(elemento).setId(id);
	}

	public Vector<ProyectoDTO> getProyectosDTO() {
		return proyectosDTO;
	}

	public void setProyectosDTO(Vector<ProyectoDTO> proyectosDTO) {
		this.proyectosDTO = proyectosDTO;
	}
	
	public int getSize()
	{
		return this.getProyectosDTO().size();
	}
	
}
