package es.uco.iw.mvc.vista.display;

import java.util.Vector;

public class ProyectoBean {
    private String titulo;
	private String descripcion;
	private Vector <String> skills;
	private Vector <String> tematicas;
    private String propietario;
    private Vector <String> colaboradores;
    private byte[] multimedia;
    private int id;

    public ProyectoBean (String titulo, String descripcion, Vector <String> skills, 
								Vector <String> tematicas, String propietario)
	{
		setTitulo(titulo);
		setDescripcion(descripcion);
		setSkills(new Vector <String>());
		setSkills(skills);
        setTematicas(new Vector <String>());
		setTematicas(tematicas);
		setPropietario(propietario);
		
	}

    public ProyectoBean() {
    	setTitulo(null);
		setDescripcion(null);
		setSkills(null);
		setSkills(null);
        setTematicas(null);
		setTematicas(null);
		setPropietario(null);
	}

    
    
	public ProyectoBean(String titulo, String descripcion, Vector<String> skills, Vector<String> tematicas,
			String propietario, byte[] multimedia, Vector<String> participantes, int id) {
		setTitulo(titulo);
		setDescripcion(descripcion);
		setSkills(skills);
		setTematicas(tematicas);
		setPropietario(propietario);
		setMultimedia(multimedia);
		setColaboradores(participantes);
		setId(id);
	}

	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

    public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

    public Vector <String> getSkills() {
		return skills;
	}

	public void setSkills(Vector <String> skills) {
		this.skills = skills;
	}

    public Vector <String> getTematicas() {
		return tematicas;
	}

	public void setTematicas(Vector <String> tematicas) {
		this.tematicas = tematicas;
	}

    public String getPropietario() {
		return propietario;
	}

	public void setPropietario(String propietario) {
		this.propietario = propietario;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Vector<String> getColaboradores() {
		return colaboradores;
	}

	public void setColaboradores(Vector<String> colaboradores) {
		this.colaboradores = colaboradores;
	}

	public byte[] getMultimedia() {
		return multimedia;
	}

	public void setMultimedia(byte[] multimedia) {
		this.multimedia = multimedia;
	}
	
	
}
