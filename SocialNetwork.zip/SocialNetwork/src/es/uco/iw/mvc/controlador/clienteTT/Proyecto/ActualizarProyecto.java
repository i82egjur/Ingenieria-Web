package es.uco.iw.mvc.controlador.clienteTT.Proyecto;

import java.io.IOException;
import java.util.Arrays;
import java.util.Vector;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import es.uco.iw.mvc.modelo.business.ProyectoDTO;
import es.uco.iw.mvc.modelo.data.clienteTiburonToro.Proyecto.ActualizarProyectoDAO;
import es.uco.iw.mvc.modelo.data.clienteTiburonToro.Proyecto.GetDataProyecto;
import es.uco.iw.mvc.modelo.data.clienteTiburonToro.Proyecto.impl.GestionarProyectosDAO;
import es.uco.iw.mvc.modelo.data.clienteTiburonToro.gestCTT.GestSkillCtt;
import es.uco.iw.mvc.modelo.data.clienteTiburonToro.gestCTT.impl.GestSkillCTTImpl;
import es.uco.iw.mvc.vista.display.ProyectoBean;

/**
 * Servlet implementation class ActualizarProyecto
 */
public class ActualizarProyecto extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ActualizarProyecto() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String idProyecto =  request.getParameter("idProyecto");
		request.getSession().setAttribute("idProyecto", idProyecto);
		
		GestSkillCtt gestorSkills = new GestSkillCTTImpl(request.getServletContext());

		Vector <String> skillsCompletas = gestorSkills.getTotalSkills();
		request.getSession().setAttribute("Skills", skillsCompletas);
	
		Vector <String> tematicasCompletas = gestorSkills.getTotalTematicas();
		
		request.getSession().setAttribute("tematicas", tematicasCompletas);
		
		String direccionAredirigir = this.getServletContext().getContextPath()
									+ "/Vista/clienteTiburonToro/proyecto/actualizarProyecto.jsp";
        
		response.sendRedirect(direccionAredirigir);	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession sesion = request.getSession();
		String mailUsuarioLogado = (String)sesion.getAttribute("mailUsuarioLogado");
		
		String id = (String)sesion.getAttribute("idProyecto");
		String titulo = request.getParameter("Titulo");
		String descripcion = request.getParameter("descripcion");
		String[] skills =request.getParameterValues("skills");
		String[] tematicas =request.getParameterValues("tematicas");
		Vector <String> skillsrecibidas= null;
		Vector <String> tematicasRecibidas= null;
		Integer idProyecto = Integer.parseInt(id);
		
		skillsrecibidas= new Vector <String>(Arrays.asList(skills));
		tematicasRecibidas= new Vector <String>(Arrays.asList(tematicas));

		
		ProyectoDTO proyectoDTO = new ProyectoDTO(titulo, descripcion,  skillsrecibidas, tematicasRecibidas, mailUsuarioLogado);
		proyectoDTO.setId(idProyecto);	
		
		ActualizarProyectoDAO actualizar = new GestionarProyectosDAO(this.getServletContext());
		
		actualizar.actualizarProyecto(proyectoDTO );
		String direccionAredirigir = this.getServletContext().getContextPath()
				+ "/Vista/clienteTiburonToro/proyecto/actualizarProyecto.jsp";

		response.sendRedirect(direccionAredirigir);	
	}

}
