package es.uco.iw.mvc.controlador.clienteTT.Proyecto;

import java.io.IOException;
import java.util.Vector;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import es.uco.iw.mvc.modelo.business.ProyectoDTO;
import es.uco.iw.mvc.modelo.data.clienteTiburonToro.Proyecto.ActualizarProyectoDAO;
import es.uco.iw.mvc.modelo.data.clienteTiburonToro.Proyecto.impl.GestionarProyectosDAO;
import es.uco.iw.mvc.vista.display.MisProyectosBean;

/**
 * Servlet implementation class mostrarMisProyectos
 */
public class MostrarMisProyectos extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MostrarMisProyectos() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession sesion = request.getSession();
		
		String loginMail = (String)sesion.getAttribute("mailUsuarioLogado");
		if (loginMail == null)
		{
			 response.sendRedirect(this.getServletContext().getContextPath()+"/index.jsp");
		}
		else
		{
		
			ActualizarProyectoDAO actualizar = new GestionarProyectosDAO(this.getServletContext());
			Vector <ProyectoDTO> proyectosDTO =  actualizar.getMisProyectosColaborativos(loginMail);
			MisProyectosBean proyectosAmostrar = new MisProyectosBean(proyectosDTO);
			request.getSession().setAttribute("proyectosAmostrar", proyectosAmostrar);
			
			response.sendRedirect(this.getServletContext().getContextPath()+"/Vista/clienteTiburonToro/proyecto/misProyectosColaborativos.jsp");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
