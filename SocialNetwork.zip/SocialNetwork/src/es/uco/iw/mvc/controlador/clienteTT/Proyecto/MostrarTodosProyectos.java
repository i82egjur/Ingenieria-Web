package es.uco.iw.mvc.controlador.clienteTT.Proyecto;

import java.io.IOException;
import java.util.Vector;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import es.uco.iw.mvc.modelo.business.ProyectoDTO;
import es.uco.iw.mvc.modelo.data.clienteTiburonToro.Proyecto.GetDataProyecto;
import es.uco.iw.mvc.modelo.data.clienteTiburonToro.Proyecto.impl.GestionarProyectosDAO;
import es.uco.iw.mvc.vista.display.ProyectoBean;

/**
 * Servlet implementation class MostrarTodosProyectos
 */

public class MostrarTodosProyectos extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MostrarTodosProyectos() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		GetDataProyecto getDataProyecto = new GestionarProyectosDAO(this.getServletContext());

		Vector<ProyectoDTO>nuevoProyecto = getDataProyecto.obtenerTotalProyectos();
		
		Vector <ProyectoBean> proyectosMostrar = new Vector<ProyectoBean>();
		for(int i=0; i<nuevoProyecto.size();i++)
		{
			proyectosMostrar.add(new ProyectoBean( nuevoProyecto.get(i).getTitulo(),  nuevoProyecto.get(i).getDescripcion(), 
					nuevoProyecto.get(i).getSkills(),  nuevoProyecto.get(i).getTematicas(),
					nuevoProyecto.get(i).getPropietario(), nuevoProyecto.get(i).getMultimedia(),  nuevoProyecto.get(i).getParticipantes(),  nuevoProyecto.get(i).getId()));
		}
		
		
		request.getSession().setAttribute("proyectosMostrar", proyectosMostrar);
		String direccionAredirigir = this.getServletContext().getContextPath()+"/Vista/proyectosPromocionativos.jsp";
        response.sendRedirect(direccionAredirigir);	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}