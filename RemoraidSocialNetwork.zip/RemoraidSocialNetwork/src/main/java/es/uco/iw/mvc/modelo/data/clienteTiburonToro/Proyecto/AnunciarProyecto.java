package es.uco.iw.mvc.modelo.data.clienteTiburonToro.Proyecto;

public interface AnunciarProyecto {

}
