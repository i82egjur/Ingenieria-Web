package es.uco.iw.mvc.modelo.data.clienteTiburonToro.colaboraciones;

public interface GestColaboracionDAO {

}
