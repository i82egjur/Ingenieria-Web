package es.uco.iw.mvc.modelo.data.remoraRegistrada.controlAcceso;

import es.uco.iw.mvc.modelo.business.RemoraRegistradaDTO;

public interface Register {
	
	public int register(RemoraRegistradaDTO remoraRegistrada);

}
