package es.uco.iw.mvc.modelo.data.clienteTiburonToro.gestCTT;

public interface PromocionarUsuario {

}
