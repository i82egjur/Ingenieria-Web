package es.uco.iw.mvc.modelo.data.remoraRegistrada.controlAcceso;


public interface Login 
{
	
	public boolean login(String mail, String PasswdEncriptada);


}
