package es.uco.iw.mvc.modelo.data.clienteTiburonToro.colaboraciones.impl;

public class GestColaboracionDAOImpl {

}
