package es.uco.iw.mvc.controlador.GestRemora.controlAcceso;

import java.io.IOException;
import java.util.Arrays;
import java.util.Vector;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import es.uco.iw.mvc.modelo.data.remoraRegistrada.impl.RemoraDAO;
import es.uco.iw.mvc.modelo.business.TipoRemora;

/**
 * Servlet implementation class RegistroController
 */
public class RegistroController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegistroController() {
        super();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		response.sendRedirect(this.getServletContext().getContextPath()+"/Vista/remoraRegistrada/controlAcceso/registrarUsuario.jsp");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		String nombre = request.getParameter("nombre");
		System.out.println(nombre);

		String apellidos = request.getParameter("apellidos");
		System.out.println(apellidos);

		String mail = request.getParameter("mail");
		System.out.println(mail);

		String password= request.getParameter("password");
		System.out.println(password);

		String saltPasswd= request.getParameter("salt");
		System.out.println(saltPasswd);

		String telefono = request.getParameter("telefono");
	

		Vector<String> skills_Vect = new Vector<String>(Arrays.asList(request.getParameterValues("intereses")));
		
		
	
		RemoraDAO remoraDAO = new RemoraDAO (this.getServletContext());
		//FactoriaRemoraRegistrada fact = new FactoriaRemoraRegistrada();
		
		/*remoraDAO.registrarRemora(
				FactoriaRemoraRegistrada.createRemoraRegistrada(
							nombre, apellidos, mail, password, saltPasswd, new Integer(telefono), 
							TipoRemora.ClienteTiburonToro, skills_Vect));*/
		
		
		
	}

}
