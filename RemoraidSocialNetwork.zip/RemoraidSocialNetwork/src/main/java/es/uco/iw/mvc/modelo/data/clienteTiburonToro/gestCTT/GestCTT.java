package es.uco.iw.mvc.modelo.data.clienteTiburonToro.gestCTT;

import es.uco.iw.mvc.modelo.business.ClienteTiburonToro;

public class GestCTT
{
	public void crearCTT(ClienteTiburonToro newCliente)
	{
		
	}
	
	
	public void updateCTT(ClienteTiburonToro updateCliente)
	{
		
	}
	
	public void eraseCTT(ClienteTiburonToro eraseCliente)
	{
		
	}
	
	public void searchCTT(String mail)
	{
		
	}
}
