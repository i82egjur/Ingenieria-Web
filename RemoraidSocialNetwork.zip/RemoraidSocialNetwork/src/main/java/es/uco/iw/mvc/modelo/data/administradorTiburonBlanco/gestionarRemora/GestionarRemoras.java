package es.uco.iw.mvc.modelo.data.administradorTiburonBlanco.gestionarRemora;

public interface GestionarRemoras {

}
