package es.uco.iw.mvc.modelo.data.remoraRegistrada.impl;

import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Properties;

import  es.uco.iw.mvc.modelo.data.remoraRegistrada.controlAcceso.Login;
import  es.uco.iw.mvc.modelo.data.conexionBBDD.DBconnect;



public class LoginRemoraDAO implements Login
{
	private Connection con;
	private Properties pSQL;
	
	public LoginRemoraDAO (DBconnect dbConnect)
	{
		con = dbConnect.getConnection();
		pSQL = new Properties();
		try
		{
			
			String path = this.getClass().getResource("../../../../sql.properties").toURI().getPath();
			System.out.println(path);
			pSQL.load(new FileInputStream(path));
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}

	private String getSalt(String mail)
	{
		String salt = null;
		ResultSet rs = null;
		PreparedStatement ps = null;
		
		try
		{
			ps = con.prepareStatement(pSQL.getProperty("getSalt"));
			ps.setString(1, mail);
		    rs = ps.executeQuery();
			if (!rs.wasNull())
			{
				salt = rs.getString(1);
			}
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return salt;
	}
	private boolean existsRemora(String mail)
	{
		ResultSet rs = null;
		PreparedStatement ps = null;
		
		try
		{
			ps = con.prepareStatement(pSQL.getProperty("existsRemora"));
			ps.setString(1, mail);
		    rs = ps.executeQuery();
			if (!rs.wasNull())
			{
				return true;
			}
			
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return false;

	}
	
	private String getPasswdEncript(String mail)
	{
		String remoraPasswd = null;
		ResultSet rs = null;
		PreparedStatement ps = null;
		
		try
		{
			ps = con.prepareStatement(pSQL.getProperty("getPasswdEncript"));
			ps.setString(1, mail);
		    rs = ps.executeQuery();
			if (!rs.wasNull())
			{
				remoraPasswd = rs.getString(1);
			}
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return remoraPasswd;
	}
	
	private String encriptarCadena (String CadenaAencriptar)
	{
		String cadenaEncriptada = "";
		
		return cadenaEncriptada;
		
	}

	public boolean login(String mail, String PasswdEncriptada)
	{
		String saltRemora = getSalt(mail);
		String passwdAlmacenada = getPasswdEncript(mail);
		String passwdAComparar = encriptarCadena(saltRemora + passwdAlmacenada);
		if (existsRemora(mail))
		{
			if (passwdAlmacenada.equals(passwdAComparar))
			{
				return true;
			}	
		}
		
		return false;
		
	}
	
}
