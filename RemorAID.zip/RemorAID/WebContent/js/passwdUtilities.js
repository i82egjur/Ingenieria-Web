function generarCadenaAleatoria()
{
   var result           = '';
   var characters       = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
   var charactersLength = characters.length;
   for ( var i = 0; i < 6; i++ ) 
	{
      result += characters.charAt(Math.floor(Math.random() * charactersLength));
   }
   return result;
};

function cifrarLoginPasswd()
{
	var loginPasswd = document.getElementById("loginPasswd");
	var loginPasswdEncript = encriptarCadena(loginPasswd.value);
	loginPasswd.value = loginPasswdEncript;
};


function encriptarCadena(cadena)
{
	  var cadenaEncriptada;
	  var objetoHash = new jsSHA("SHA-512", "TEXT", {numRounds: 1});
	  objetoHash.update(cadena);
	  cadenaEncriptada = objetoHash.getHash("HEX");
  

	  return cadenaEncriptada;
};

function formatSalt()
{
  var saltSinEncriptar = generarCadenaAleatoria();
  var saltEncriptado = encriptarCadena(saltSinEncriptar);
  return saltEncriptado;
}


function formatPassword(passwd, saltHTML)
{
	
  var passwdEncriptado = encriptarCadena(passwd);
  var passwdFinal = passwdEncriptado.concat('', saltHTML);
  passwdFinal = encriptarCadena(passwdFinal);
  return passwdFinal;

}

function validarNombre(nombre)
{
	caracteresPermitidos = /[^a-zA-Z0-9_-]/;
	if(nombre == "" || nombre==null)
	{
		return "No se introdujo nombre de usuario\n";
	}
	else if (caracteresPermitidos.test(nombre))
	{
		return "Caracteres inválidos en nombre de usuario\n" ;
	}
	else
	{
		return "";
	}
}


function validarApellidos(apellidos)
{
	caracteresPermitidos = /[^a-zA-Z0-9_-]/;
	if(apellidos == "" || apellidos==null)
	{
		return "No se introdujo apellidos de usuario\n";
	}
	else if (caracteresPermitidos.test(apellidos))
	{
		return "Caracteres inválidos en apellidos de usuario\n" ;
	}
	else
	{
		return "";
	}
}

function validarMail(mail)
{
	caracteresPermitidos = /[^a-zA-Z0-9\.\@\_\-]/;
	if(mail == "" || mail==null)
	{
		return "No se introdujo mail de usuario\n";
	}
	if ((mail.indexOf("@") <= 0) || caracteresPermitidos.test(mail))
	{
		return "Mail en formato incorrecto\n" ;
	}
	else
	{
		return "";
	}
}

function validarTelefono(telefono)
{
	caracteresPermitidos = /[0-9]{10}/;
	if(telefono == "" || telefono==null)
	{
		return "No se introdujo telefono de usuario\n";
	}
	else if (caracteresPermitidos.test(telefono))
	{
		return "Caracteres inválidos en telefono de usuario\n" ;
	}
	else
	{
		return "";
	}
}

function validarPassword(password, checkPassword)
{
	if(password == "" || password==null)
	{
		return "No se introdujo password de usuario\n";
	}
	else if (checkPassword == "" || checkPassword==null)
	{
		return "No se introdujo check de password\n" ;
	}
	else if (checkPassword != password)
	{
		return "La password y su check no coinciden\n" ;
	}
	else
	{
		return "";
	}
	
}




function validarFormularioRegistroUsuario(form) 
{
	fallo = validarPassword(form.password.value, form.checkPassword.value);
	
	if (fallo == "")
	{
		form.salt.value = formatSalt();
		form.encriptPasswd.value = formatPassword(form.password.value, form.salt.value);

	}
		

	
	fallo += validarNombre(form.nombre.value);
	fallo += validarApellidos(form.apellidos.value);
	fallo += validarMail(form.mail.value);
	fallo+= validarTelefono(form.telefono.value);
	if(fallo == "")
	{
		return true;
	}
	else
	{
		alert(fallo);
		return false;
	}

};



function checkmail()
{
	var mail = document.getElementById("mail");
	var tituloSkill = document.getElementById("TituloSkill");
	var tipoRemora = document.getElementById("tipoRemora");
	var listaSkill = document.getElementById("listaSkill");
	if(mail.value.includes("@remoraid.es"))
	{
		tipoRemora.value="AdministradorTiburonBlanco";
		var tituloSkillHTML = ``
		tituloSkill.innerHTML=tituloSkillHTML;
		if (listaSkill.style.display=="block")
		{
			listaSkill.style.display="none";
		}
	}		
	else
	{
		tipoRemora.value="ClienteTiburonToro";
		var tituloSkillHTML = `<label for="nombre">Skills:</label>`
		tituloSkill.innerHTML=tituloSkillHTML;
		if (listaSkill.style.display=="none")
		{
			listaSkill.style.display = "block";
		}


	}
	

};













