package es.uco.iw.mvc.controlador.clienteTT.Proyecto;

import java.io.IOException;
import java.util.Arrays;
import java.util.Vector;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import es.uco.iw.mvc.modelo.business.ProyectoDTO;
import es.uco.iw.mvc.modelo.data.clienteTiburonToro.Proyecto.AnunciarProyecto;
import es.uco.iw.mvc.modelo.data.clienteTiburonToro.Proyecto.impl.GestionarProyectosDAO;
import es.uco.iw.mvc.modelo.data.clienteTiburonToro.gestCTT.GestSkillCtt;
import es.uco.iw.mvc.modelo.data.clienteTiburonToro.gestCTT.impl.GestSkillCTTImpl;

/**

/**
 * Servlet implementation class CompartirProyecto
 */
public class CrearProyecto extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CrearProyecto() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		GestSkillCtt gestorSkills = new GestSkillCTTImpl(request.getServletContext());

		Vector <String> skillsCompletas = gestorSkills.getTotalSkills();
		System.out.println(skillsCompletas.toString());

		request.getSession().setAttribute("Skills", skillsCompletas);
	
		Vector <String> tematicasCompletas = gestorSkills.getTotalTematicas();
		System.out.println(tematicasCompletas.toString());
		
		request.getSession().setAttribute("tematicas", tematicasCompletas);

		
		String direccionAredirigir = this.getServletContext().getContextPath()
									+ "/Vista/clienteTiburonToro/proyecto/crearProyecto.jsp";
        
		response.sendRedirect(direccionAredirigir);	
        
	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession sesion = request.getSession();
		String mailUsuarioLogado = (String)sesion.getAttribute("mailUsuarioLogado");
		
		
		String titulo = request.getParameter("Titulo");
		String descripcion = request.getParameter("descripcion");
		String[] skills =request.getParameterValues("skills");
		String[] tematicas =request.getParameterValues("tematicas");
		Vector <String> skillsrecibidas= null;
		Vector <String> tematicasRecibidas= null;

		skillsrecibidas= new Vector <String>(Arrays.asList(skills));
		tematicasRecibidas= new Vector <String>(Arrays.asList(tematicas));

		
		ProyectoDTO proyecto = new ProyectoDTO(titulo, descripcion,  skillsrecibidas, tematicasRecibidas, mailUsuarioLogado);
			
		AnunciarProyecto anunciar = new GestionarProyectosDAO(this.getServletContext());
		anunciar.subirProyecto(proyecto);
		String direccionAredirigir = this.getServletContext().getContextPath()
				+ "/Vista/clienteTiburonToro/proyecto/crearProyecto.jsp";

		response.sendRedirect(direccionAredirigir);	
	}

}
