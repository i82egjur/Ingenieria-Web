package es.uco.iw.mvc.controlador.clienteTT.Proyecto;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import es.uco.iw.mvc.modelo.data.clienteTiburonToro.Proyecto.impl.GestionarProyectosDAO;
import es.uco.iw.mvc.modelo.business.MultimediaDTO;
import es.uco.iw.mvc.modelo.data.clienteTiburonToro.Proyecto.CompartirProyecto;
/**
 * Servlet implementation class AnunciarProyecto
 */
public class AnunciarProyecto extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AnunciarProyecto() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession sesion = request.getSession();
		String idProyectoSesion = (String)sesion.getAttribute("idProyecto");
		String contenido =  request.getParameter("binarioApasar");
		CompartirProyecto anunciar = new GestionarProyectosDAO(this.getServletContext());
		Integer idProyecto = Integer.parseInt(idProyectoSesion);
		MultimediaDTO multimedia = new MultimediaDTO(idProyecto,"pdf", contenido.getBytes());
		anunciar.compartir(multimedia);
		
		String direccionAredirigir = this.getServletContext().getContextPath()
				+ "/MenuPrincipal";

		response.sendRedirect(direccionAredirigir);	
	}

}
