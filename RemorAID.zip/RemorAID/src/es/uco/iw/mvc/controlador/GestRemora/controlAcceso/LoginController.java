package es.uco.iw.mvc.controlador.GestRemora.controlAcceso;

import java.io.IOException;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import es.uco.iw.mvc.modelo.business.TipoRemora;
import es.uco.iw.mvc.modelo.data.remoraRegistrada.controlAcceso.Login;
import es.uco.iw.mvc.modelo.data.remoraRegistrada.impl.LoginRemoraDAO;


/**
 * Servlet implementation class LoginController
 */

public class LoginController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.sendRedirect(this.getServletContext().getContextPath()+"/Vista/remoraRegistrada/controlAcceso/login.jsp");
		
	}	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String loginMail = request.getParameter("login-mail");

		String loginPass = request.getParameter("login-pass");

		 Login loginGEST = new LoginRemoraDAO(this.getServletContext());
		 boolean loginResult = loginGEST.login(loginMail, loginPass);
		 
		 	
		 if (loginResult)
		 {
			 request.getSession().setAttribute("mailUsuarioLogado", loginMail);
			 TipoRemora tipoRemora = loginGEST.getTipoRemora(loginMail);
			 
			
			 //Concatenamos el path de contexto de la aplicacion con el menu principal predeterminado para cada tipo de remora
			 ServletContext context = this.getServletContext();
			 String parametroBuscarDeXML = "MenuPrincipalDe"+ tipoRemora.toString();
			 String urlRedireccion = context.getContextPath() 
					 								+ context.getInitParameter(parametroBuscarDeXML);
			 
			 response.sendRedirect(urlRedireccion);
		

		 }
		 else
		 {
			 response.sendRedirect(this.getServletContext().getContextPath()+"/index.jsp");

		 }
		 
		
	}

}
