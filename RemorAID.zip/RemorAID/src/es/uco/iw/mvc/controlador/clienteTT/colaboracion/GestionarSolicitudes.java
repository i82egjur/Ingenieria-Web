package es.uco.iw.mvc.controlador.clienteTT.colaboracion;

import java.io.IOException;
import java.util.Hashtable;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import es.uco.iw.mvc.modelo.data.clienteTiburonToro.colaboraciones.GestColaboracionDAO;
import es.uco.iw.mvc.modelo.data.clienteTiburonToro.colaboraciones.impl.GestColaboracionDAOImpl;

/**
 * Servlet implementation class GestionarSolicitudes
 */

public class GestionarSolicitudes extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public GestionarSolicitudes() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String usuarioLogado=(String) request.getSession().getAttribute("mailUsuarioLogado");
        GestColaboracionDAO gestorSolicitudes = new GestColaboracionDAOImpl(this.getServletContext());
        Hashtable <String, Integer> solicitudes=gestorSolicitudes.mostrarSolicitudesRecibidas(usuarioLogado);
       
        request.getSession().setAttribute("Solicitudes", solicitudes);
		
		
		String direccionAredirigir = this.getServletContext().getContextPath()+"/Vista/clienteTiburonToro/colaboracion/gestionarSolicitudes.jsp";
		response.sendRedirect(direccionAredirigir);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at:2 ").append(request.getContextPath());
	}

}
