package es.uco.iw.mvc.controlador.clienteTT.Proyecto;

import java.io.IOException;
import java.util.Vector;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import es.uco.iw.mvc.modelo.business.ProyectoDTO;
import es.uco.iw.mvc.modelo.data.clienteTiburonToro.Proyecto.GetDataProyecto;
import es.uco.iw.mvc.modelo.data.clienteTiburonToro.Proyecto.impl.GestionarProyectosDAO;
import es.uco.iw.mvc.vista.display.ProyectoBean;

/**
 * Servlet implementation class MostrarProyecto
 */
@WebServlet("/MostrarProyecto")
public class MostrarProyecto extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MostrarProyecto() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//Integer idProyecto = (Integer) request.getAttribute("IDproyecto");
		
		
		String idRecibido = request.getParameter("idProyecto");
		System.out.println(idRecibido);
		System.out.println("sdfsdfasdfasdfasdfas");
		if (idRecibido == null || idRecibido=="")
		{
			System.out.println(idRecibido);

			String direccionAredirigir = this.getServletContext().getContextPath()
					+ "/MostrarMisProyectos";
			response.sendRedirect(direccionAredirigir);
		}
		else
		{
		
			Integer idProyecto = Integer.parseInt(idRecibido);

		
		
			
			GetDataProyecto getDataProyecto = new GestionarProyectosDAO(this.getServletContext());
			ProyectoDTO proyect = getDataProyecto.getProyecto(idProyecto);
			ProyectoBean nuevoProyecto = new ProyectoBean (proyect.getTitulo(), proyect.getDescripcion(), proyect.getSkills(), 
														proyect.getTematicas(), proyect.getPropietario(), proyect.getMultimedia(),
														proyect.getParticipantes(), proyect.getId());
	
			request.getSession().setAttribute("proyectoAmostrar", nuevoProyecto);
			
			String direccionAredirigir = this.getServletContext().getContextPath()
										+ "/Vista/clienteTiburonToro/proyecto/imprimirProyecto.jsp";
	        
			response.sendRedirect(direccionAredirigir);	
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
