package es.uco.iw.mvc.controlador.clienteTT.promocion;

import java.io.IOException;
import java.sql.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import es.uco.iw.mvc.modelo.business.PromocionClienteTiburonToroDTO;
import es.uco.iw.mvc.modelo.data.clienteTiburonToro.promocion.GestPromocionRemoraDAO;
import es.uco.iw.mvc.modelo.data.clienteTiburonToro.promocion.impl.GestPromocionRemoraDAOImpl;
import es.uco.iw.mvc.vista.display.PromocionBean;

/**
 * Servlet implementation class Promocionarme
 */
public class PromocionarRemora extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PromocionarRemora() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		GestPromocionRemoraDAO gestPromo = new GestPromocionRemoraDAOImpl(this.getServletContext());
		HttpSession sesion = request.getSession();
		String mailUsuarioLogado = (String) sesion.getAttribute("mailUsuarioLogado");
		
		PromocionClienteTiburonToroDTO promocionObtenida = gestPromo.getPromocionCTT(mailUsuarioLogado);
		if(promocionObtenida!= null)
		{
			PromocionBean promocionAPasar = new PromocionBean(promocionObtenida);
			request.getSession().setAttribute("promocionesAmostrar", promocionAPasar);
		}
		else
		{
			request.getSession().setAttribute("promocionesAmostrar", null);

		}
	
		String direccionAredirigir = this.getServletContext().getContextPath()+"/Vista/clienteTiburonToro/gestCliente/promocionarCliente.jsp";
		response.sendRedirect(direccionAredirigir);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession sesion = request.getSession();
		String mailUsuarioLogado = (String) sesion.getAttribute("mailUsuarioLogado");
		GestPromocionRemoraDAO gestPromoRemora = new GestPromocionRemoraDAOImpl(this.getServletContext());

		
		if (mailUsuarioLogado == null)
		{
			String direccionAredirigir = this.getServletContext().getContextPath()+"/index.jsp";
			response.sendRedirect(direccionAredirigir);
		}
		else
		{
			if(gestPromoRemora.hasPromocion(mailUsuarioLogado))
			{
				String direccionAredirigir = this.getServletContext().getContextPath()+"/";
				response.sendRedirect(direccionAredirigir);
			}
			else
			{
				String descripcion = request.getParameter("descripcion");
				String fechaInicioRecibir = request.getParameter("inicio");	
				String fechaFinalRecibir = request.getParameter("final");
				
				Date fechaInicio = Date.valueOf(fechaInicioRecibir);
				Date fechaFinal = Date.valueOf(fechaFinalRecibir);

				PromocionClienteTiburonToroDTO newPromo = 
											new PromocionClienteTiburonToroDTO (mailUsuarioLogado, "", "", descripcion, fechaInicio, fechaFinal);
				
				gestPromoRemora.promocionarClienteTiburonToro(newPromo);
				String direccionAredirigir = this.getServletContext().getContextPath()+"/Vista/clienteTiburonToro/gestCliente/promocionarCliente.jsp";
				response.sendRedirect(direccionAredirigir);
			}
			
		
		}
	}

}
