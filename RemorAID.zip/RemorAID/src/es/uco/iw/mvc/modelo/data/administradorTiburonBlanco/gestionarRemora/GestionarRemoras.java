package es.uco.iw.mvc.modelo.data.administradorTiburonBlanco.gestionarRemora;

public interface GestionarRemoras 
{
	public Integer banearRemora(String email);

}
