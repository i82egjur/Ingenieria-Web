package es.uco.iw.mvc.modelo.data.remoraRegistrada.controlAcceso;

import es.uco.iw.mvc.modelo.business.TipoRemora;

public interface Login 
{
	
	public boolean login(String mail, String PasswdEncriptada);
	public TipoRemora getTipoRemora (String mail); 


}
