package es.uco.iw.mvc.modelo.data.administradorTiburonBlanco.gestionarRemora.impl;

import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.Properties;

import javax.servlet.ServletContext;

import es.uco.iw.mvc.modelo.data.administradorTiburonBlanco.gestionarRemora.GestionarRemoras;
import es.uco.iw.mvc.modelo.data.conexionBBDD.impl.DBconnectImpl;

public class GestionarRemoraImpl  implements GestionarRemoras
{

	DBconnectImpl dbConnect;
	Connection conexionBBDD;
	private Properties pSQL;
	
	public GestionarRemoraImpl (ServletContext servletContext){
		
		dbConnect = new DBconnectImpl(servletContext);

		pSQL = new Properties();
		conexionBBDD = dbConnect.getConnection();
		try
		{
			
			String path = this.getClass().getResource(servletContext.getInitParameter("pathProperties")).toURI().getPath();
			pSQL.load(new FileInputStream(path));
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}		
	}
	
	public Integer banearRemora(String email) {
		
		PreparedStatement subirProyecto = null;
		int status = 0;

		try
		{
			subirProyecto=conexionBBDD.prepareStatement(pSQL.getProperty("banearRemora"));
			subirProyecto.setString(1, email);			
			
			
			status = subirProyecto.executeUpdate();
						
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		return status;				
	}
	
}