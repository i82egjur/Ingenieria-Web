package es.uco.iw.mvc.modelo.data.clienteTiburonToro.Proyecto;

public interface DeleteProyecto 
{
	
	public Integer borrarProyecto(int id);

}
