package es.uco.iw.mvc.modelo.data.clienteTiburonToro.Proyecto.impl;


import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;
import java.util.Vector;

import javax.servlet.ServletContext;

import es.uco.iw.mvc.modelo.business.MultimediaDTO;
import es.uco.iw.mvc.modelo.business.ProyectoDTO;
import es.uco.iw.mvc.modelo.data.clienteTiburonToro.Proyecto.ActualizarProyectoDAO;
import es.uco.iw.mvc.modelo.data.clienteTiburonToro.Proyecto.AnunciarProyecto;
import es.uco.iw.mvc.modelo.data.clienteTiburonToro.Proyecto.CompartirProyecto;
import es.uco.iw.mvc.modelo.data.clienteTiburonToro.Proyecto.DeleteProyecto;
import es.uco.iw.mvc.modelo.data.clienteTiburonToro.Proyecto.GetDataProyecto;
import es.uco.iw.mvc.modelo.data.conexionBBDD.impl.DBconnectImpl;

public class GestionarProyectosDAO implements AnunciarProyecto, CompartirProyecto, ActualizarProyectoDAO, DeleteProyecto, GetDataProyecto
{

	DBconnectImpl dbConnect;
	Connection conexionBBDD;
	private Properties pSQL;
	
	public GestionarProyectosDAO(ServletContext servletContext) 
	{
		dbConnect = new DBconnectImpl(servletContext);

		pSQL = new Properties();
		conexionBBDD = dbConnect.getConnection();
		try
		{
			
			String path = this.getClass().getResource(servletContext.getInitParameter("pathProperties")).toURI().getPath();
			pSQL.load(new FileInputStream(path));
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}
	
	
	public Integer subirProyecto(ProyectoDTO proyectoDTO) 
	{
		PreparedStatement subirProyecto = null;
		int status = 0;

		try
		{
			subirProyecto=conexionBBDD.prepareStatement(pSQL.getProperty("subirProyecto"), Statement.RETURN_GENERATED_KEYS);
			subirProyecto.setString(1, proyectoDTO.getTitulo());
			subirProyecto.setString(2, proyectoDTO.getDescripcion());
			subirProyecto.setString(3, proyectoDTO.getPropietario());
	
			
			status = subirProyecto.executeUpdate();
			
			try (ResultSet generatedKeys = subirProyecto.getGeneratedKeys()) {

                if (generatedKeys.next()) {

                    int id;
                    id = generatedKeys.getInt(1);

                    System.out.println("ID del Proyecto: " + "<" + id + ">");          
                    
                    subirProyectoSkills(proyectoDTO, id);
                    subirProyectoTematicas(proyectoDTO, id);

                }

                else {
                    throw new SQLException("Creating proyect failed, no ID obtained.");
                }
            }
			
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		return status;
	}
	
	private void subirProyectoSkills(ProyectoDTO proyectoDTO, int id) 
	{
		PreparedStatement subirProyectoSkills = null;
	
		try
		{
			for(String string : proyectoDTO.getSkills()) {
				
				subirProyectoSkills=conexionBBDD.prepareStatement(pSQL.getProperty("subirProyectoSkills"));
				subirProyectoSkills.setInt(1, id);
				subirProyectoSkills.setString(2, string);
								
				subirProyectoSkills.executeUpdate();
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}
	
	private void subirProyectoTematicas(ProyectoDTO proyectoDTO, int id) 
	{
		PreparedStatement subirProyectoTematicas = null;
	
		try
		{
			for(String string : proyectoDTO.getTematicas()) {
				
				subirProyectoTematicas=conexionBBDD.prepareStatement(pSQL.getProperty("subirProyectoTematicas"));
				subirProyectoTematicas.setInt(1, id);
				subirProyectoTematicas.setString(2, string);
								
				subirProyectoTematicas.executeUpdate();
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}
	public Integer compartir(MultimediaDTO multimedia) 
	{
		PreparedStatement subirMultimedia = null;
		int status = 0;

		try
		{
			subirMultimedia=conexionBBDD.prepareStatement(pSQL.getProperty("insertarFoto"));
			subirMultimedia.setString(1, multimedia.getTipoMultimedia());
			subirMultimedia.setBytes(2, multimedia.getMultimedia());
			subirMultimedia.setInt(3, multimedia.getID_proyecto());
	
			
			status = subirMultimedia.executeUpdate();
			              
			
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		return status;
	}
	public Integer borrarProyecto(int id) 
	{
		PreparedStatement subirProyecto = null;
		int status = 0;

		try
		{
			subirProyecto=conexionBBDD.prepareStatement(pSQL.getProperty("borrarProyecto"));
			subirProyecto.setInt(1, id);
						
			status = subirProyecto.executeUpdate();
				
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		return status;
	}
	public Integer actualizarProyecto(ProyectoDTO proyectoDTO) 
	{
		PreparedStatement subirProyecto = null;
		int status = 0;

		try
		{
			subirProyecto=conexionBBDD.prepareStatement(pSQL.getProperty("actualizarProyecto"));
			subirProyecto.setString(1, proyectoDTO.getTitulo());
			subirProyecto.setString(2, proyectoDTO.getDescripcion());
			subirProyecto.setInt(3, proyectoDTO.getId());
		
			
			status = subirProyecto.executeUpdate();
			
			actualizarProyectoSkills(proyectoDTO);
			actualizarProyectoTematicas(proyectoDTO);
			
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		return status;
	}
	
	private void actualizarProyectoSkills(ProyectoDTO proyectoDTO) 
	{
		PreparedStatement actualizarProyectoSkills = null;
		if(proyectoDTO.getSkills() != null)
		{
				
			try
			{
				actualizarProyectoSkills=conexionBBDD.prepareStatement(pSQL.getProperty("borrarProyectoSkills"));
				actualizarProyectoSkills.setInt(1, proyectoDTO.getId());
				actualizarProyectoSkills.executeUpdate();
				
				
				for(String string : proyectoDTO.getSkills()) {
					
					actualizarProyectoSkills=conexionBBDD.prepareStatement(pSQL.getProperty("subirProyectoSkills"));
					actualizarProyectoSkills.setInt(1, proyectoDTO.getId());
					actualizarProyectoSkills.setString(2, string);
									
					actualizarProyectoSkills.executeUpdate();
				}
			}
			catch (Exception e)
			{
				e.printStackTrace();
			}
		}
	}
	
	private void actualizarProyectoTematicas(ProyectoDTO proyectoDTO) 
	{
		PreparedStatement actualizarProyectoTematicas = null;
		if(proyectoDTO.getTematicas() != null)
		{
			try
			{
				actualizarProyectoTematicas=conexionBBDD.prepareStatement(pSQL.getProperty("borrarProyectoTematicas"));
				actualizarProyectoTematicas.setInt(1, proyectoDTO.getId());
				actualizarProyectoTematicas.executeUpdate();
				
				for(String string : proyectoDTO.getTematicas()) {
					
					actualizarProyectoTematicas=conexionBBDD.prepareStatement(pSQL.getProperty("subirProyectoTematicas"));
					actualizarProyectoTematicas.setInt(1, proyectoDTO.getId());
					actualizarProyectoTematicas.setString(2, string);
									
					actualizarProyectoTematicas.executeUpdate();
				}
			}
			catch (Exception e)
			{
				e.printStackTrace();
			}
		}
	}


	public Vector<ProyectoDTO> getMisProyectosColaborativos(String mail)
	{
		ResultSet rs = null;
		PreparedStatement ps = null;
		Vector <ProyectoDTO> proyectos = new Vector <ProyectoDTO>();
		ProyectoDTO nuevo = null;
		try
		{
			ps = conexionBBDD.prepareStatement(pSQL.getProperty("getMisProyectos"));
			ps.setString(1, mail);
		    rs = ps.executeQuery();
			while (rs.next())
			{
				nuevo = new ProyectoDTO();
				nuevo.setId(rs.getInt(1));
				nuevo.setDescripcion(rs.getString(2));
				nuevo.setTitulo(rs.getString(3));
		
				proyectos.add(nuevo);			
				
			}
			for (ProyectoDTO proyecto: proyectos)
			{
				System.out.println(proyecto.getDescripcion() +" "+ proyecto.getTitulo());
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return proyectos;
	}
	
	public byte[] obtenerMultimedia(Integer id)
	{
		ResultSet rs = null;
		PreparedStatement ps = null;
		byte[] multimedia = null;
		try
		{
			ps = conexionBBDD.prepareStatement(pSQL.getProperty("ObtenerMultimediaProyecto"));
			ps.setInt(1, id);
		    rs = ps.executeQuery();
			if (rs.next())
			{
				multimedia = rs.getBytes(1);
				
			}
		
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return multimedia;
	}

	public Vector <String> obtenerSkillsProyecto(Integer id)
	{
		ResultSet rs = null;
		PreparedStatement ps = null;
		Vector <String> skillsProyecto = new Vector <String>();
		try
		{
			ps = conexionBBDD.prepareStatement(pSQL.getProperty("obtenerSkillsProyecto"));
			ps.setInt(1, id);
		    rs = ps.executeQuery();
			while (rs.next())
			{
				skillsProyecto.add(rs.getString(1));
				
			}
		
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return skillsProyecto;
	}
	
	
	public Vector <String> ObtenerTematicasProyecto(Integer id)
	{
		ResultSet rs = null;
		PreparedStatement ps = null;
		Vector <String> tematica = new Vector <String>();

		try
		{
			ps = conexionBBDD.prepareStatement(pSQL.getProperty("obtenerTematicaProyecto"));
			ps.setInt(1, id);
		    rs = ps.executeQuery();
			while (rs.next())
			{
				tematica.add(rs.getString(1));
							
			}
		
	
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return tematica;
	}
	
	
	public Vector <String> ObtenerColaboradoresProyecto (Integer id)
	{
		ResultSet rs = null;
		PreparedStatement ps = null;
		Vector <String> colaboradores = new Vector <String>();

		try
		{
			ps = conexionBBDD.prepareStatement(pSQL.getProperty("ObtenerParticipantesProyecto"));
			ps.setInt(1, id);
		    rs = ps.executeQuery();
			while (rs.next())
			{
				colaboradores.add(rs.getString(1));
							
			}
	
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return colaboradores;
	}
	
	public ProyectoDTO getProyecto(Integer id)
	{
		ResultSet rs = null;
		PreparedStatement ps = null;
		ProyectoDTO proyectoObtenido = new ProyectoDTO();
		try
		{
			ps = conexionBBDD.prepareStatement(pSQL.getProperty("getProyecto"));
			ps.setInt(1, id);
		    rs = ps.executeQuery();
			if (rs.next())
			{			
				proyectoObtenido.setDescripcion(rs.getString(1));
				proyectoObtenido.setTitulo(rs.getString(2));
				proyectoObtenido.setPropietario(rs.getString(3));
				proyectoObtenido.setId(id);
				proyectoObtenido.setParticipantes(ObtenerColaboradoresProyecto(id));
				proyectoObtenido.setSkills(obtenerSkillsProyecto(id));
				proyectoObtenido.setTematicas(ObtenerTematicasProyecto(id));
				proyectoObtenido.setMultimedia(obtenerMultimedia(id));
				
				
				
			}
	
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	

		return proyectoObtenido;
	}
	
	public Vector<ProyectoDTO> buscarProyecto(String valor)
	{
		ResultSet rs = null;
		PreparedStatement ps = null;
		Vector <ProyectoDTO> proyecto = new Vector <ProyectoDTO>();
		ProyectoDTO proyectoObtenido = null; 
		
		try
		{
			ps = conexionBBDD.prepareStatement(pSQL.getProperty("buscarProyecto"));
			ps.setString(1, valor);
			ps.setString(2, valor);
		    rs = ps.executeQuery();
			
		    while (rs.next())
			{			
		    	proyectoObtenido=new ProyectoDTO();
		    	proyectoObtenido.setDescripcion(rs.getString(1));
				proyectoObtenido.setTitulo(rs.getString(2));
				System.out.println("titulo busqueda: " + rs.getString(2));
				proyectoObtenido.setPropietario(rs.getString(3));
				proyectoObtenido.setId(rs.getInt(4));
				int id= rs.getInt(4);
				proyectoObtenido.setParticipantes(ObtenerColaboradoresProyecto(id));
				proyectoObtenido.setSkills(obtenerSkillsProyecto(id));
				proyectoObtenido.setTematicas(ObtenerTematicasProyecto(id));
				proyectoObtenido.setMultimedia(obtenerMultimedia(id));
				
				proyecto.add(proyectoObtenido);
				
			}
		    
	
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}


		return proyecto;
	}
	
	public Vector <ProyectoDTO> obtenerTotalProyectos()
	{
		ResultSet rs = null;
		PreparedStatement ps = null;
		Vector <ProyectoDTO> totalProyectos = new Vector <ProyectoDTO>();

		try
		{
			ps = conexionBBDD.prepareStatement(pSQL.getProperty("obtenerId"));
		    rs = ps.executeQuery();
			while (rs.next())
			{
				totalProyectos.add(getProyecto(rs.getInt(1)));
							
			}
	
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return totalProyectos;
	}

}