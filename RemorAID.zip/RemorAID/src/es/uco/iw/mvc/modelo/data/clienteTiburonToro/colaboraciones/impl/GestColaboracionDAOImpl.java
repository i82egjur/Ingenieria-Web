package es.uco.iw.mvc.modelo.data.clienteTiburonToro.colaboraciones.impl;

import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Hashtable;
import java.util.Properties;

import javax.servlet.ServletContext;

import es.uco.iw.mvc.modelo.data.clienteTiburonToro.colaboraciones.GestColaboracionDAO;
import es.uco.iw.mvc.modelo.data.conexionBBDD.DBconnect;
import es.uco.iw.mvc.modelo.data.conexionBBDD.impl.DBconnectImpl;

public class GestColaboracionDAOImpl implements GestColaboracionDAO
{
	private Connection conexionBBDD;
	private Properties pSQL;
	
	public GestColaboracionDAOImpl(ServletContext servletContext)
	{
		DBconnect dbConnect = new DBconnectImpl(servletContext);
		conexionBBDD = dbConnect.getConnection();
		pSQL = new Properties();
		conexionBBDD = dbConnect.getConnection();
		try
		{
			
			String path = this.getClass().getResource(servletContext.getInitParameter("pathProperties")).toURI().getPath();
			System.out.println(path);
			pSQL.load(new FileInputStream(path));
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	public void registrarSolicitud(Integer idProyecto, String mailRemoraEmisora)
	{
		PreparedStatement registrarSolicitud = null;
		
		try
		{
			registrarSolicitud=conexionBBDD.prepareStatement(pSQL.getProperty("registrarSolicitudProyecto"), Statement.RETURN_GENERATED_KEYS);
			
			registrarSolicitud.setInt(1, idProyecto);
			
			registrarSolicitud.executeUpdate();
			
			try (ResultSet generatedKeys = registrarSolicitud.getGeneratedKeys()) {

                if (generatedKeys.next()) {

                    int id;
                    id = generatedKeys.getInt(1);

                    System.out.println("ID de la Solicitud: " + "<" + id + ">");          
                                     
                    registrarSolicitudEmisor(id, mailRemoraEmisora);
                    registrarSolicitudReceptor(id, idProyecto);

                }

                else {
                    throw new SQLException("Creating proyect failed, no ID obtained.");
                }
            }
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}	
	}
	
	public void registrarSolicitud(String mailRemoraEmisora, String mailRemoraReceptora)
	{
		PreparedStatement registrarSolicitud = null;
		
		try
		{
			registrarSolicitud=conexionBBDD.prepareStatement(pSQL.getProperty("registrarSolicitudPromocion"), Statement.RETURN_GENERATED_KEYS);
			
			registrarSolicitud.executeUpdate();
			
			try (ResultSet generatedKeys = registrarSolicitud.getGeneratedKeys()) {

                if (generatedKeys.next()) {

                    int id;
                    id = generatedKeys.getInt(1);

                    System.out.println("ID de la Solicitud: " + "<" + id + ">");          
                                     
                    registrarSolicitudEmisor(id, mailRemoraEmisora);
                    registrarSolicitudReceptor(id, mailRemoraReceptora);

                }

                else {
                    throw new SQLException("Creating proyect failed, no ID obtained.");
                }
            }
			
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}	
	}
	
	public void registrarSolicitudEmisor(int id, String mailRemoraEmisora)
	{
		PreparedStatement registrarSolicitud = null;
		try
		{
			registrarSolicitud=conexionBBDD.prepareStatement(pSQL.getProperty("registrarSolicitudEmisor"));
			
			registrarSolicitud.setInt(1, id);
			registrarSolicitud.setString(2, mailRemoraEmisora);
			
			registrarSolicitud.executeUpdate();
			
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}	
	}
	
	public void registrarSolicitudReceptor(int id, int idProyecto)
	{
		PreparedStatement registrarSolicitud = null;
		try
		{
			registrarSolicitud=conexionBBDD.prepareStatement(pSQL.getProperty("registrarSolicitudReceptorProyecto"));
			
			registrarSolicitud.setInt(1, id);
			registrarSolicitud.setInt(2, idProyecto);
			
			registrarSolicitud.executeUpdate();
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}	
	}
	
	public void registrarSolicitudReceptor(int id, String mailRemoraReceptora)
	{
		PreparedStatement registrarSolicitud = null;
		try
		{
			registrarSolicitud=conexionBBDD.prepareStatement(pSQL.getProperty("registrarSolicitudReceptor"));
			
			registrarSolicitud.setInt(1, id);
			registrarSolicitud.setString(2, mailRemoraReceptora);
			
			registrarSolicitud.executeUpdate();
			
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}	
	}
	
	public Hashtable <String, Integer> mostrarSolicitudesRecibidas(String mailRemoraReceptora)
	{
		//En esta tabla hash, almacenamos el mail del solicitante y el id del proyecto sobre el que se quiere solicitar colaboracion
		Hashtable <String, Integer> solicitudes = new Hashtable <String, Integer>();
		ResultSet rs = null;
		PreparedStatement ps = null;
		try
		{
			ps = conexionBBDD.prepareStatement(pSQL.getProperty("mostrarSolicitudesRecibidas"));
			ps.setString(1, mailRemoraReceptora);
			rs = ps.executeQuery();
			while (rs.next())
			{
				solicitudes.put(rs.getString(1), rs.getInt(2));
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return solicitudes;
	}

	public void aceptarSolicitud(String mailRemoraEmisora, Integer idSolicitud)
	{
		PreparedStatement aceptarSolicitud = null;
		try
		{
			aceptarSolicitud=conexionBBDD.prepareStatement(pSQL.getProperty("aceptarSolicitud"));
			aceptarSolicitud.setString(1, mailRemoraEmisora);
			aceptarSolicitud.setInt(2, idSolicitud);
			aceptarSolicitud.executeUpdate();		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		
	}
	public void denegarSolicitud(Integer idSolicitud)
	{
		PreparedStatement denegarSolicitud = null;
		try
		{
			denegarSolicitud=conexionBBDD.prepareStatement(pSQL.getProperty("eliminarSolicitud"));
			denegarSolicitud.setInt(1, idSolicitud);
			denegarSolicitud.executeUpdate();
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		
	}
}
