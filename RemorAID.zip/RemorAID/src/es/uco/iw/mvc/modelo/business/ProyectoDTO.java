package es.uco.iw.mvc.modelo.business;

import java.util.Vector;

public class ProyectoDTO {
    
    private String titulo;
	private String descripcion;
	private Vector <String> skills;
	private Vector <String> tematicas;
    private String propietario;
    private byte[] multimedia;
    private Vector <String> participantes;
    private int id;

    public ProyectoDTO (String titulo, String descripcion, Vector <String> skills, 
								Vector <String> tematicas, String propietario)
	{
		setTitulo(titulo);
		setDescripcion(descripcion);
		setSkills(new Vector <String>());
		setSkills(skills);
        setTematicas(new Vector <String>());
		setTematicas(tematicas);
		setPropietario(propietario);
	}

    public ProyectoDTO() {
    	setTitulo(null);
		setDescripcion(null);
		setSkills(null);
		setSkills(null);
        setTematicas(null);
		setTematicas(null);
		setPropietario(null);
	}

	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

    public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

    public Vector <String> getSkills() {
		return skills;
	}

	public void setSkills(Vector <String> skills) {
		this.skills = skills;
	}

    public Vector <String> getTematicas() {
		return tematicas;
	}

	public void setTematicas(Vector <String> tematicas) {
		this.tematicas = tematicas;
	}

    public String getPropietario() {
		return propietario;
	}

	public void setPropietario(String propietario) {
		this.propietario = propietario;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public void setMultimedia(byte[] multimedia) {
		this.multimedia = multimedia;
	}

	public void setParticipantes(Vector<String> participantes) {
		this.participantes = participantes;
	}

	public byte[] getMultimedia() {
		return multimedia;
	}

	public Vector<String> getParticipantes() {
		return participantes;
	}
	
	
}
