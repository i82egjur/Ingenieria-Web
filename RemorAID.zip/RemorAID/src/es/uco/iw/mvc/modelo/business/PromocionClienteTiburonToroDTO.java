package es.uco.iw.mvc.modelo.business;

import java.sql.Date;

public class PromocionClienteTiburonToroDTO 
{
	String correo;
	String nombre;
	String apellidos;
	String descripcionPromocion;
	Date fechaInicio;
	Date fechaFinal;

	
	public PromocionClienteTiburonToroDTO(String correo, String nombre, String apellidos, 
											String descripcionPromocion, Date fechaInicio,
											Date fechaFinal)
	{
		setCorreo(correo);
		setNombre(nombre);
		setApellidos(apellidos);
		setDescripcionPromocion(descripcionPromocion);
		setFechaInicio(fechaInicio);
		setFechaFinal(fechaFinal);
	}
	
	
	public String getCorreo() {
		return correo;
	}

	public void setCorreo(String correo) {
		this.correo = correo;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellidos() {
		return apellidos;
	}

	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}

	public String getDescripcionPromocion() {
		return this.descripcionPromocion;
	}

	public void setDescripcionPromocion(String descripcionPromocion) {
		this.descripcionPromocion = descripcionPromocion;
	}

	public Date getFechaInicio() {
		return this.fechaInicio;
	}

	public void setFechaInicio(Date fechaInicio) {
		this.fechaInicio = fechaInicio;
	}
	public Date getFechaFinal() {
		return fechaFinal;
	}


	public void setFechaFinal(Date fechaFinal) {
		this.fechaFinal = fechaFinal;
	}



}
