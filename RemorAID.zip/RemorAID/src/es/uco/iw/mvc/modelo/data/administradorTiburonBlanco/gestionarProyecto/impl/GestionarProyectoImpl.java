package es.uco.iw.mvc.modelo.data.administradorTiburonBlanco.gestionarProyecto.impl;

import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.Properties;

import javax.servlet.ServletContext;

import es.uco.iw.mvc.modelo.data.administradorTiburonBlanco.gestionarProyecto.GestionarProyecto;
import es.uco.iw.mvc.modelo.data.conexionBBDD.impl.DBconnectImpl;

public class GestionarProyectoImpl implements GestionarProyecto
{

	DBconnectImpl dbConnect;
	Connection conexionBBDD;
	private Properties pSQL;
	
	
	public GestionarProyectoImpl(ServletContext servletContext) {
		
		dbConnect = new DBconnectImpl(servletContext);

		pSQL = new Properties();
		conexionBBDD = dbConnect.getConnection();
		try
		{
			
			String path = this.getClass().getResource(servletContext.getInitParameter("pathProperties")).toURI().getPath();
			pSQL.load(new FileInputStream(path));
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}		
	}
	
	
	public Integer banearProyecto(int id) {
		
		PreparedStatement subirProyecto = null;
		int status = 0;

		try
		{
			subirProyecto=conexionBBDD.prepareStatement(pSQL.getProperty("borrarProyecto"));
			subirProyecto.setInt(1, id);
			
			status = subirProyecto.executeUpdate();
						
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		return status;		
	}
}