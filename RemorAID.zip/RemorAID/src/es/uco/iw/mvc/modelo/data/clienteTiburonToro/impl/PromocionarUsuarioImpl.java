package es.uco.iw.mvc.modelo.data.clienteTiburonToro.impl;

public class PromocionarUsuarioImpl {

}
