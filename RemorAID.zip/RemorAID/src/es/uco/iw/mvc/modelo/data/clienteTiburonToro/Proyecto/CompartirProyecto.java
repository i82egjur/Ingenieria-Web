package es.uco.iw.mvc.modelo.data.clienteTiburonToro.Proyecto;

import es.uco.iw.mvc.modelo.business.MultimediaDTO;

public interface CompartirProyecto 
{
	public Integer compartir(MultimediaDTO multimedia);

}
