package es.uco.iw.mvc.vista.display;

import java.sql.Date;
import java.util.Vector;

import es.uco.iw.mvc.modelo.business.PromocionClienteTiburonToroDTO;

public class PromocionBean 
{
	private Vector <PromocionClienteTiburonToroDTO> promCTT;
	String correo;
	String nombre;
	String apellidos;
	String descripcionPromocion;
	Date fechaInicio;
	Date fechaFinal;

	
	
	
	public PromocionBean(Vector <PromocionClienteTiburonToroDTO> promCTT)
	{
		setPromCTT(promCTT);
	}
	

	
	public PromocionBean(PromocionClienteTiburonToroDTO newSingleProm) 
	{
		setCorreo(newSingleProm.getCorreo());
		setNombre(newSingleProm.getNombre());
		setApellidos(newSingleProm.getApellidos());
		setDescripcionPromocion(newSingleProm.getDescripcionPromocion());
		setFechaInicio(newSingleProm.getFechaInicio());
		setFechaFinal(newSingleProm.getFechaFinal());	
		setPromCTT(new Vector <PromocionClienteTiburonToroDTO> ());
        getPromCTT().add(newSingleProm);
	}



	public Vector<PromocionClienteTiburonToroDTO> getPromCTT() {
		return promCTT;
	}


	public void setPromCTT(Vector<PromocionClienteTiburonToroDTO> promCTT) {
		this.promCTT = promCTT;
	}

	public Integer size()
	{
		return this.promCTT.size();
	}
	
	public String getCorreo(Integer pos) {
		return this.promCTT.get(pos).getCorreo();
	}


	public String getNombre(Integer pos) {
		return this.promCTT.get(pos).getNombre();
	}



	public String getApellidos(Integer pos) {
		return this.promCTT.get(pos).getApellidos();
	}



	public String getDescripcionPromocion(Integer pos) {
		return this.promCTT.get(pos).getDescripcionPromocion();
	}


	public Date getFechaInicio(Integer pos) {
		return this.promCTT.get(pos).getFechaInicio();
	}


	public Date getFechaFinal(Integer pos) {
		return this.promCTT.get(pos).getFechaFinal();
	}

	public String getCorreo() {
		return correo;
	}

	public void setCorreo(String correo) {
		this.correo = correo;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellidos() {
		return apellidos;
	}

	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}

	public String getDescripcionPromocion() {
		return this.descripcionPromocion;
	}

	public void setDescripcionPromocion(String descripcionPromocion) {
		this.descripcionPromocion = descripcionPromocion;
	}

	public Date getFechaInicio() {
		return this.fechaInicio;
	}

	public void setFechaInicio(Date fechaInicio) {
		this.fechaInicio = fechaInicio;
	}
	public Date getFechaFinal() {
		return fechaFinal;
	}


	public void setFechaFinal(Date fechaFinal) {
		this.fechaFinal = fechaFinal;
	}



}
