package es.uco.iw.mvc.controlador.buscar;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import es.uco.iw.mvc.modelo.business.PromocionClienteTiburonToroDTO;
import es.uco.iw.mvc.modelo.data.clienteTiburonToro.promocion.GestPromocionRemoraDAO;
import es.uco.iw.mvc.modelo.data.clienteTiburonToro.promocion.impl.GestPromocionRemoraDAOImpl;
import es.uco.iw.mvc.vista.display.PromocionBean;

/**
 * Servlet implementation class BuscarUsuario
 */
public class BuscarUsuario extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public BuscarUsuario() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		GestPromocionRemoraDAO gestPromo;
        PromocionClienteTiburonToroDTO promocionObtenida;
        PromocionBean promocionAPasar;

        String buscar=request.getParameter("buscar");
        System.out.println("Busqueda.java -> Barra de busqueda: " + buscar);


        gestPromo = new GestPromocionRemoraDAOImpl(this.getServletContext());
        promocionObtenida = gestPromo.getPromocionCTT(buscar);

        if(promocionObtenida != null) { promocionAPasar = new PromocionBean(promocionObtenida);    }

        else { promocionAPasar=null; }
        request.getSession().setAttribute("promocionesAmostrar", promocionAPasar);


        String direccionAredirigir = this.getServletContext().getContextPath()+"/Vista/mostrarPromocionRemora.jsp";
        response.sendRedirect(direccionAredirigir);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
