package es.uco.iw.mvc.controlador.clienteTT.gestCTT;

import java.io.IOException;
import java.util.Arrays;
import java.util.Vector;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import es.uco.iw.mvc.modelo.business.ClienteTiburonToro;
import es.uco.iw.mvc.modelo.data.clienteTiburonToro.gestCTT.GestCTT;
import es.uco.iw.mvc.modelo.data.clienteTiburonToro.gestCTT.GestSkillCtt;
import es.uco.iw.mvc.modelo.data.clienteTiburonToro.gestCTT.impl.GestCTTImpl;
import es.uco.iw.mvc.modelo.data.clienteTiburonToro.gestCTT.impl.GestSkillCTTImpl;

/**
 * Servlet implementation class ActualizarPerfil
 */
public class ActualizarPerfil extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ActualizarPerfil() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		GestSkillCtt gestorSkills = new GestSkillCTTImpl(request.getServletContext());

		Vector <String> skillsCompletas = gestorSkills.getTotalSkills();
		request.getSession().setAttribute("Skills", skillsCompletas);
	
		
		String direccionAredirigir = this.getServletContext().getContextPath()+"/Vista/clienteTiburonToro/gestCliente/modificarPerfil.jsp";
        response.sendRedirect(direccionAredirigir);	
        }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String nombre = request.getParameter("nombre");
		String apellidos = request.getParameter("apellidos");
		String telefono = request.getParameter("telefono");
		String mail = request.getParameter("mail");
		String[] skills =request.getParameterValues("skills");
		Vector <String> skillsrecibidas= null;
		
		String usuarioLogado=(String) request.getSession().getAttribute("mailUsuarioLogado");

		GestCTT gestor = new GestCTTImpl(this.getServletContext());
		ClienteTiburonToro clienteAux = gestor.searchCTT(usuarioLogado);

		

		if(skills!=null)
		{
			skillsrecibidas= new Vector <String>(Arrays.asList(skills));
		}
		
		
		if (nombre!="")
		{
			clienteAux.setNombreRemora(nombre);

		}
		
		if (apellidos!="")
		{
			clienteAux.setApellidos(apellidos);
		}

		if (telefono!="")
		{
			int telefonoaux = Integer.parseInt(telefono);
			clienteAux.setTelefono(telefonoaux);
		}
		
		if (mail!="")
		{
			clienteAux.setMail(mail);
		}
		
		if (skillsrecibidas != null)
		{
			clienteAux.setSkills(skillsrecibidas);
		}
		
		gestor.updateCTT(clienteAux);

		String direccionAredirigir = this.getServletContext().getContextPath()+"/Vista/menuPrincipal.jsp";
		response.sendRedirect(direccionAredirigir);
	}

}