package es.uco.iw.mvc.controlador.administradorTiburonBlanco.gestionarProyectos;

import java.io.IOException;
import java.util.Vector;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import es.uco.iw.mvc.modelo.business.ProyectoDTO;
import es.uco.iw.mvc.modelo.data.administradorTiburonBlanco.gestionarProyecto.GestionarProyecto;
import es.uco.iw.mvc.modelo.data.administradorTiburonBlanco.gestionarProyecto.impl.GestionarProyectoImpl;
import es.uco.iw.mvc.modelo.data.clienteTiburonToro.Proyecto.GetDataProyecto;
import es.uco.iw.mvc.modelo.data.clienteTiburonToro.Proyecto.impl.GestionarProyectosDAO;
import es.uco.iw.mvc.vista.display.ProyectoBean;

/**
 * Servlet implementation class ReportarProyecto
 */
public class ReportarProyecto extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ReportarProyecto() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		GetDataProyecto getDataProyecto = new GestionarProyectosDAO(this.getServletContext());

		Vector<ProyectoDTO>nuevoProyecto = getDataProyecto.obtenerTotalProyectos();
		
		Vector <ProyectoBean> proyectosMostrar = new Vector<ProyectoBean>();
		for(int i=0; i<nuevoProyecto.size();i++)
		{
			proyectosMostrar.add(new ProyectoBean( nuevoProyecto.get(i).getTitulo(),  nuevoProyecto.get(i).getDescripcion(), 
					nuevoProyecto.get(i).getSkills(),  nuevoProyecto.get(i).getTematicas(),
					nuevoProyecto.get(i).getPropietario(), nuevoProyecto.get(i).getMultimedia(),  nuevoProyecto.get(i).getParticipantes(),  nuevoProyecto.get(i).getId()));
		}
		
		
		request.getSession().setAttribute("proyectosMostrar", proyectosMostrar);
		String direccionAredirigir = this.getServletContext().getContextPath()+"/Vista/administradorTiburonBlanco/reportarProyecto.jsp";
        response.sendRedirect(direccionAredirigir);
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		GestionarProyecto gest = new GestionarProyectoImpl(this.getServletContext());
		
		String idAnuncioRecibido=request.getParameter("idAnuncio");
			Integer idAnuncioAreportar = Integer.parseInt(idAnuncioRecibido);
			gest.banearProyecto(idAnuncioAreportar);
			 response.sendRedirect(this.getServletContext().getContextPath()+"/Vista/administradorTiburonBlanco/menuPrincipalATB.jsp");
	}

}
