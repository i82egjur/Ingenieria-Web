package es.uco.iw.mvc.modelo.data.administradorTiburonBlanco.gestionarProyecto;

public interface GestionarProyecto 
{
	public Integer banearProyecto(int id);


}
