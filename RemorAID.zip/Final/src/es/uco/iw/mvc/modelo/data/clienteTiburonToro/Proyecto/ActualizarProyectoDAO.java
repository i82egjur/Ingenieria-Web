package es.uco.iw.mvc.modelo.data.clienteTiburonToro.Proyecto;

import java.util.Vector;

import es.uco.iw.mvc.modelo.business.ProyectoDTO;

public interface ActualizarProyectoDAO 
{
	public Integer actualizarProyecto(ProyectoDTO proyectoDTO) ;
	public Vector <ProyectoDTO> getMisProyectosColaborativos(String mail);
	
}
