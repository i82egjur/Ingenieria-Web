package es.uco.iw.mvc.vista.display;

public class RemoraBean {

}
