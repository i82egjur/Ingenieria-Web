package es.uco.iw.mvc.vista.display;

import java.sql.Date;
import java.util.Vector;

import es.uco.iw.mvc.modelo.business.PromocionClienteTiburonToroDTO;

public class PromocionBean 
{
	Vector <PromocionClienteTiburonToroDTO> promCTT;

	
	public PromocionBean(Vector <PromocionClienteTiburonToroDTO> promCTT)
	{
		setPromCTT(promCTT);
	}
	
	public Vector<PromocionClienteTiburonToroDTO> getPromCTT() {
		return promCTT;
	}


	public void setPromCTT(Vector<PromocionClienteTiburonToroDTO> promCTT) {
		this.promCTT = promCTT;
	}

	public Integer size()
	{
		return this.promCTT.size();
	}
	
	public String getCorreo(Integer pos) {
		return this.promCTT.get(pos).getCorreo();
	}


	public String getNombre(Integer pos) {
		return this.promCTT.get(pos).getNombre();
	}



	public String getApellidos(Integer pos) {
		return this.promCTT.get(pos).getApellidos();
	}



	public String getDescripcionPromocion(Integer pos) {
		return this.promCTT.get(pos).getDescripcionPromocion();
	}


	public Date getFechaInicio(Integer pos) {
		return this.promCTT.get(pos).getFechaInicio();
	}


	public Date getFechaFinal(Integer pos) {
		return this.promCTT.get(pos).getFechaFinal();
	}





}
