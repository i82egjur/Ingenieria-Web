package es.uco.iw.mvc.modelo.data.clienteTiburonToro.promocion;

import java.util.Vector;

import es.uco.iw.mvc.modelo.business.PromocionClienteTiburonToroDTO;

public interface GestPromocionRemoraDAO 
{
	public Vector <PromocionClienteTiburonToroDTO> getClientesTiburonToroPromocionados();
	

	public void promocionarClienteTiburonToro(PromocionClienteTiburonToroDTO promocionarUsuario);

}
