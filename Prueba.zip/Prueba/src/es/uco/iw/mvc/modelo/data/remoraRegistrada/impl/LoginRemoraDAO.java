package es.uco.iw.mvc.modelo.data.remoraRegistrada.impl;

import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Properties;
import javax.servlet.ServletContext;
import java.math.BigInteger; 
import java.security.MessageDigest; 
import java.security.NoSuchAlgorithmException; 

import  es.uco.iw.mvc.modelo.data.remoraRegistrada.controlAcceso.Login;
import es.uco.iw.mvc.modelo.business.Passwd;
import es.uco.iw.mvc.modelo.business.TipoRemora;
import  es.uco.iw.mvc.modelo.data.conexionBBDD.DBconnect;
import es.uco.iw.mvc.modelo.data.conexionBBDD.impl.DBconnectImpl;
import es.uco.iw.mvc.modelo.data.remoraRegistrada.GestInformacionRemora.GestRemora;



public class LoginRemoraDAO implements Login
{
	private Connection con;
	private Properties pSQL;
	private GestRemora gestorRemora;
	
	public LoginRemoraDAO(ServletContext servletContext)
	{
		gestorRemora = new GestRemoraImpl(servletContext);
		DBconnect dbConnect = new DBconnectImpl(servletContext);
		con = dbConnect.getConnection();
		pSQL = new Properties();
		try
		{
			
			String path = this.getClass().getResource(servletContext.getInitParameter("pathProperties")).toURI().getPath();
			pSQL.load(new FileInputStream(path));
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}

	private Passwd getPasswd(String mail)
	{
		Passwd passwdRemora = null;
		String salt = "";
		String fullEncriptedPasswd = "";
		ResultSet rs = null;
		PreparedStatement ps = null;
		
		try
		{
			ps = con.prepareStatement(pSQL.getProperty("getPasswdEncript"));
			ps.setString(1, mail);
		    rs = ps.executeQuery();
			if (rs.next())
			{
				fullEncriptedPasswd = rs.getString(1);
				salt = rs.getString(2);
			}
			passwdRemora = new Passwd(fullEncriptedPasswd, salt);
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return passwdRemora;
	}


	
	private String encriptarCadena (String CadenaAencriptar)
	{

		 try { 
	            // getInstance() llamamos al metodo con algoritmo SHA-512 
	            MessageDigest md = MessageDigest.getInstance("SHA-512"); 
	  
	           
	            // Calculamos el digest de la entrada se retorna un vector de byte
	            byte[] messageDigest = md.digest(CadenaAencriptar.getBytes()); 
	  
	            
	            // Convertimos el vector de bytes en una representecion signum
	            BigInteger no = new BigInteger(1, messageDigest); 
	  
	            // Convertimos el messageDigest en hexadecimal
	            String hashtext = no.toString(16); 
	  
	            // Añadimos 0s para hacerlo 32 bit 
	            while (hashtext.length() < 32) { 
	                hashtext = "0" + hashtext; 
	            } 
	  
	           return hashtext; 
	        } 
	  
	        catch (NoSuchAlgorithmException e) { 
	            throw new RuntimeException(e); 
	        } 
		
		
	}

	public boolean login(String mail, String PasswdEncriptada)
	{
		Passwd passwdRemora = getPasswd(mail);
		String saltRemora = passwdRemora.getSaltEncript();
		String passwdAlmacenada =  passwdRemora.getPasswdEncript();
		String passwdAComparar = encriptarCadena( PasswdEncriptada+saltRemora );
		System.out.println(saltRemora);
		System.out.println(passwdAlmacenada);
		System.out.println(passwdAComparar);

	
		if (gestorRemora.existsRemora(mail))
		{
		
				if (passwdAlmacenada.equals(passwdAComparar))
				{
					return true;
				}	
		
		}	
		return false;

	}

	@Override
	public TipoRemora getTipoRemora(String mail) 
	{
		String tipoRemora = null;
		ResultSet rs = null;
		PreparedStatement ps = null;
		
		try
		{
			ps = con.prepareStatement(pSQL.getProperty("getTipoRemora"));
			ps.setString(1, mail);
		    rs = ps.executeQuery();
			if (rs.next())
			{
				tipoRemora = rs.getString(1);
			}
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return TipoRemora.valueOf(tipoRemora);
	}
	

	
}
