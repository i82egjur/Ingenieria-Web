package es.uco.iw.mvc.modelo.data.administradorTiburonBlanco.gestionarRemora.impl;

public class GestionarRemora {

}
