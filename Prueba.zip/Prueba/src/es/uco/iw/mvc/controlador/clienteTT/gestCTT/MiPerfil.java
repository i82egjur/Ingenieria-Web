package es.uco.iw.mvc.controlador.clienteTT.gestCTT;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import es.uco.iw.mvc.modelo.business.ClienteTiburonToro;
import es.uco.iw.mvc.modelo.data.clienteTiburonToro.gestCTT.GestCTT;
import es.uco.iw.mvc.modelo.data.clienteTiburonToro.gestCTT.impl.GestCTTImpl;
import es.uco.iw.mvc.vista.display.ClienteTiburonToroBean;

/**
 * Servlet implementation class MiPerfil
 */
public class MiPerfil extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MiPerfil() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		HttpSession sesion = request.getSession();
		String mailUsuarioLogado = (String) sesion.getAttribute("mailUsuarioLogado");
		GestCTT gestorCTT = new GestCTTImpl(this.getServletContext());
		
		
		ClienteTiburonToro datosClienteObtenido = gestorCTT.searchCTT(mailUsuarioLogado);
		
		ClienteTiburonToroBean clienteAmostrar = 
								new ClienteTiburonToroBean(datosClienteObtenido.getNombreRemora(), datosClienteObtenido.getApellidos(),
															datosClienteObtenido.getMail(), datosClienteObtenido.getTelefono(),
															datosClienteObtenido.getSkills(), datosClienteObtenido.getEstado());
		
		request.getSession().setAttribute("clienteAmostrar", clienteAmostrar);
		String direccionAredirigir = this.getServletContext().getContextPath()+"/Vista/clienteTiburonToro/gestCliente/modificarPerfil.jsp";
		response.sendRedirect(direccionAredirigir);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
