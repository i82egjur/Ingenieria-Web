package es.uco.iw.mvc.controlador.clienteTT.gestCTT;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import es.uco.iw.mvc.modelo.data.clienteTiburonToro.gestCTT.GestCTT;
import es.uco.iw.mvc.modelo.data.clienteTiburonToro.gestCTT.impl.GestCTTImpl;

/**
 * Servlet implementation class EliminarCliente
 */

public class EliminarCliente extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EliminarCliente() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String usuarioLogado=(String) request.getSession().getAttribute("mailUsuarioLogado");
		
		GestCTT gestor = new GestCTTImpl(this.getServletContext());
		gestor.eraseCTT(usuarioLogado);
		
		String direccionAredirigir = this.getServletContext().getContextPath()+"/index.jsp";
		response.sendRedirect(direccionAredirigir);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
